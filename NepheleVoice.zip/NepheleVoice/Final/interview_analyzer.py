import json
import os
import requests
import pyttsx3
from datetime import datetime
from typing import Dict, List, Tuple

class InterviewAnalyzer:
    def __init__(self, ollama_url: str = "http://localhost:11434"):
        """
        Initialize the Interview Analyzer
        
        Args:
            ollama_url: URL for Ollama API (default: http://localhost:11434)
        """
        self.ollama_url = ollama_url
        self.tts_engine = pyttsx3.init()
        self.setup_tts()
        
    def setup_tts(self):
        """Configure text-to-speech settings"""
        try:
            # Set speech rate (words per minute)
            self.tts_engine.setProperty('rate', 180)
            
            # Set volume (0.0 to 1.0)
            self.tts_engine.setProperty('volume', 0.9)
            
            # Try to set a clearer voice if available
            voices = self.tts_engine.getProperty('voices')
            if voices:
                # Prefer female voice if available, otherwise use first voice
                for voice in voices:
                    if 'female' in voice.name.lower() or 'zira' in voice.name.lower():
                        self.tts_engine.setProperty('voice', voice.id)
                        break
                else:
                    self.tts_engine.setProperty('voice', voices[0].id)
        except Exception as e:
            print(f"Warning: TTS setup encountered an issue: {e}")
    
    def load_interview_data(self, file_path: str) -> Dict:
        """Load interview data from JSON file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return json.load(file)
        except FileNotFoundError:
            raise FileNotFoundError(f"Interview file not found: {file_path}")
        except json.JSONDecodeError:
            raise ValueError(f"Invalid JSON format in file: {file_path}")
    
    def query_gemma2(self, prompt: str) -> str:
        """Send query to Gemma2 model via Ollama"""
        try:
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json={
                    "model": "gemma2:2b",
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.3,  # Lower temperature for more consistent analysis
                        "top_p": 0.9,
                        "num_predict": 500   # Limit response length
                    }
                },
                timeout=60
            )
            
            if response.status_code == 200:
                return response.json().get('response', '').strip()
            else:
                return f"Error: Unable to get response from Gemma2 (Status: {response.status_code})"
                
        except requests.exceptions.ConnectionError:
            return "Error: Unable to connect to Ollama. Please ensure Ollama is running and Gemma2 model is installed."
        except requests.exceptions.Timeout:
            return "Error: Request timed out. The model might be taking too long to respond."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def analyze_individual_answer(self, question: str, answer: str, question_num: int) -> Dict:
        """Analyze a single question-answer pair"""
        prompt = f"""
You are an expert technical interviewer evaluating a candidate's response. 

QUESTION {question_num}: {question}

CANDIDATE'S ANSWER: {answer}

Please provide a structured analysis in the following format:

TECHNICAL ACCURACY: [Score 1-10 and brief explanation]
COMPLETENESS: [Score 1-10 and brief explanation]  
CLARITY: [Score 1-10 and brief explanation]
PRACTICAL UNDERSTANDING: [Score 1-10 and brief explanation]

STRENGTHS:
- [List 2-3 key strengths]

AREAS FOR IMPROVEMENT:
- [List 2-3 specific areas to improve]

OVERALL SCORE: [Score out of 10]

Keep your response concise and professional.
"""
        
        response = self.query_gemma2(prompt)
        return {
            'question_num': question_num,
            'question': question,
            'answer': answer,
            'analysis': response
        }
    
    def get_overall_assessment(self, interview_data: Dict, individual_analyses: List[Dict]) -> Dict:
        """Get overall assessment and hiring recommendation"""
        
        # Prepare summary of all responses for overall evaluation
        summary = "INTERVIEW SUMMARY:\n\n"
        for i, analysis in enumerate(individual_analyses, 1):
            summary += f"Question {i}: {analysis['question'][:100]}...\n"
            # Handle None values in answers
            answer = analysis['answer']
            if answer is None:
                answer = "No answer provided"
            summary += f"Answer Quality: {answer[:150]}...\n\n"
        
        prompt = f"""
You are a senior technical hiring manager reviewing a candidate's complete interview performance.

{summary}

Based on the candidate's responses to these 5 technical questions covering Python, SQL, AWS, ML, and system design, provide:

OVERALL ASSESSMENT:
1. TECHNICAL COMPETENCY: [Score 1-10 and explanation]
2. PROBLEM-SOLVING ABILITY: [Score 1-10 and explanation]
3. COMMUNICATION SKILLS: [Score 1-10 and explanation]
4. READINESS FOR ROLE: [Score 1-10 and explanation]

HIRING RECOMMENDATION: [HIRE/CONDITIONAL HIRE/DO NOT HIRE]

KEY STRENGTHS:
- [List 3-4 main strengths]

CRITICAL IMPROVEMENT AREAS:
- [List 3-4 areas needing significant improvement]

DEVELOPMENT RECOMMENDATIONS:
- [Specific suggestions for skill development]

OVERALL SCORE: [Average score out of 10]

Provide clear, actionable feedback that would help the candidate improve.
"""
        
        response = self.query_gemma2(prompt)
        
        # Extract hiring decision from response
        hiring_decision = "CONDITIONAL HIRE"  # Default
        if "DO NOT HIRE" in response.upper():
            hiring_decision = "DO NOT HIRE"
        elif "HIRE" in response.upper() and "CONDITIONAL" not in response.upper():
            hiring_decision = "HIRE"
        
        return {
            'overall_analysis': response,
            'hiring_decision': hiring_decision,
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    
    def speak_text(self, text: str):
        """Convert text to speech"""
        try:
            print(f"\n🔊 Speaking: {text[:100]}...")
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
        except Exception as e:
            print(f"Error in text-to-speech: {e}")
    
    def format_results_for_speech(self, overall_assessment: Dict) -> str:
        """Format results in a speech-friendly manner"""
        decision = overall_assessment['hiring_decision']
        
        speech_text = f"""
Interview Analysis Complete. 

Hiring Decision: {decision}.

{overall_assessment['overall_analysis']}

Analysis completed on {overall_assessment['timestamp']}.
"""
        return speech_text
    
    def save_detailed_report(self, interview_data: Dict, individual_analyses: List[Dict], 
                           overall_assessment: Dict, output_file: str):
        """Save detailed analysis report to file"""
        report = {
            'session_info': {
                'session_id': interview_data.get('session_id', 'N/A'),
                'timestamp': interview_data.get('timestamp', 'N/A'),
                'analysis_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            'hiring_decision': overall_assessment['hiring_decision'],
            'individual_question_analyses': individual_analyses,
            'overall_assessment': overall_assessment,
            'summary': {
                'total_questions': len(individual_analyses),
                'questions_answered': interview_data.get('current_question', len(individual_analyses))
            }
        }
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Detailed report saved to: {output_file}")
    
    def analyze_interview(self, file_path: str, speak_results: bool = True) -> Dict:
        """Main method to analyze interview responses"""
        print("🚀 Starting Interview Analysis...")
        print("=" * 50)
        
        # Load interview data
        try:
            interview_data = self.load_interview_data(file_path)
            print(f"📁 Loaded interview data for session: {interview_data.get('session_id', 'N/A')}")
        except Exception as e:
            print(f"❌ Error loading interview data: {e}")
            return None
        
        # Analyze each question-answer pair
        individual_analyses = []
        questions = interview_data.get('questions', [])
        answers = interview_data.get('answers', [])
        
        print(f"\n📝 Analyzing {len(questions)} questions...")
        
        for i, (question, answer) in enumerate(zip(questions, answers), 1):
            print(f"\n🔍 Analyzing Question {i}...")
            analysis = self.analyze_individual_answer(question, answer, i)
            individual_analyses.append(analysis)
            print(f"✅ Question {i} analysis complete")
        
        # Get overall assessment
        print(f"\n🎯 Generating overall assessment...")
        overall_assessment = self.get_overall_assessment(interview_data, individual_analyses)
        
        # Display results
        print("\n" + "=" * 50)
        print("📊 INTERVIEW ANALYSIS RESULTS")
        print("=" * 50)
        print(f"🏆 HIRING DECISION: {overall_assessment['hiring_decision']}")
        print(f"📅 Analysis Date: {overall_assessment['timestamp']}")
        print("\n📋 DETAILED ASSESSMENT:")
        print(overall_assessment['overall_analysis'])
        
        # Save detailed report
        output_file = f"interview_analysis_{interview_data.get('session_id', 'unknown')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        self.save_detailed_report(interview_data, individual_analyses, overall_assessment, output_file)
        
        # Speak results if requested
        if speak_results:
            print("\n🔊 Reading results aloud...")
            speech_text = self.format_results_for_speech(overall_assessment)
            self.speak_text(speech_text)
        
        return {
            'interview_data': interview_data,
            'individual_analyses': individual_analyses,
            'overall_assessment': overall_assessment,
            'report_file': output_file
        }

def main():
    """Main function to run the interview analyzer"""
    # Configuration
    QUESTIONS_FOLDER = "../shared_questions"
    
    # Initialize analyzer
    analyzer = InterviewAnalyzer()
    
    # Auto-detect JSON files in the questions folder
    if not os.path.exists(QUESTIONS_FOLDER):
        os.makedirs(QUESTIONS_FOLDER)
        print(f"📁 Created '{QUESTIONS_FOLDER}' folder")
        print("Please place your interview JSON file in this folder and run again")
        return
    
    # Find JSON files in the questions folder
    json_files = [f for f in os.listdir(QUESTIONS_FOLDER) if f.endswith('.json')]
    
    if not json_files:
        print(f"❌ No JSON files found in '{QUESTIONS_FOLDER}' folder")
        print("Please place your interview JSON file in the 'questions' folder")
        print("Supported format: any .json file with questions and answers")
        return
    
    if len(json_files) == 1:
        # Use the single JSON file found
        interview_file = json_files[0]
        file_path = os.path.join(QUESTIONS_FOLDER, interview_file)
        print(f"📁 Found interview file: {interview_file}")
    else:
        # Multiple JSON files found, let user choose
        print(f"📁 Found {len(json_files)} JSON files in '{QUESTIONS_FOLDER}':")
        for i, file in enumerate(json_files, 1):
            print(f"  {i}. {file}")
        
        try:
            choice = input("\nEnter the number of the file to analyze (or press Enter for the first one): ").strip()
            if choice == "":
                interview_file = json_files[0]
            else:
                index = int(choice) - 1
                if 0 <= index < len(json_files):
                    interview_file = json_files[index]
                else:
                    print("❌ Invalid selection. Using the first file.")
                    interview_file = json_files[0]
        except ValueError:
            print("❌ Invalid input. Using the first file.")
            interview_file = json_files[0]
        
        file_path = os.path.join(QUESTIONS_FOLDER, interview_file)
        print(f"📁 Selected file: {interview_file}")
    
    # Check if file exists (should exist since we found it, but double-check)
    if not os.path.exists(file_path):
        print(f"❌ File not found: {file_path}")
        print("Please ensure your interview JSON file is in the 'questions' folder")
        return
    
    # Run analysis
    try:
        results = analyzer.analyze_interview(file_path, speak_results=True)
        
        if results:
            print(f"\n🎉 Analysis completed successfully!")
            print(f"📄 Detailed report: {results['report_file']}")
            
            # Quick summary
            decision = results['overall_assessment']['hiring_decision']
            if decision == "HIRE":
                print("✅ Recommendation: HIRE - Candidate shows strong technical competency")
            elif decision == "CONDITIONAL HIRE":
                print("⚠️ Recommendation: CONDITIONAL HIRE - Candidate needs some development")
            else:
                print("❌ Recommendation: DO NOT HIRE - Candidate needs significant improvement")
                
    except Exception as e:
        print(f"❌ Error during analysis: {e}")

if __name__ == "__main__":
    main()